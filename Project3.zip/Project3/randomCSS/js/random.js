// AS SOON AS THE PAGE IS LOADED, RUN THIS JQUERY;
$( document ).ready(function() {

  var FuckYou = Math.random() * 300;

  $('h1').css(
    "font-size",FuckYou
  );

});
